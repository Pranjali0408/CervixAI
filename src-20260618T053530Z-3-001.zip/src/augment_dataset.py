"""
Offline augmentation script.
Run ONCE before training:  python augment_dataset.py

What it does:
  - Reads each class folder under data/sipakmed/
  - Generates augmented copies until total images >= TARGET_TOTAL
  - Saves augmented images into the SAME folder (aug_NNNN_original.jpg)
  - Skips folders that already have enough images
  - Is safe to re-run (skips already-augmented images)

Run:  python augment_dataset.py [--target 10000] [--dry-run]
"""

import os, sys, argparse, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PIL import Image, ImageEnhance, ImageFilter
import numpy as np
from config import IMAGE_DIR

TARGET_TOTAL = 10_000   # total images across all classes after augmentation
SEED         = 42
random.seed(SEED)
np.random.seed(SEED)

SUPPORTED_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


# ──────────────────────────────────────────────
#  Augmentation transforms (PIL only — no deps)
# ──────────────────────────────────────────────

def _random_flip(img):
    if random.random() > 0.5:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    if random.random() > 0.5:
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
    return img


def _random_rotate(img):
    angle = random.choice([0, 90, 180, 270])
    if angle:
        img = img.rotate(angle, expand=False)
    return img


def _random_color_jitter(img):
    img = ImageEnhance.Brightness(img).enhance(random.uniform(0.75, 1.25))
    img = ImageEnhance.Contrast(img).enhance(random.uniform(0.80, 1.20))
    img = ImageEnhance.Color(img).enhance(random.uniform(0.85, 1.15))
    return img


def _random_blur(img):
    if random.random() > 0.7:
        img = img.filter(ImageFilter.GaussianBlur(radius=random.uniform(0.3, 0.8)))
    return img


def _random_crop_resize(img, size=224):
    w, h = img.size
    crop_frac = random.uniform(0.80, 1.0)
    cw, ch    = int(w * crop_frac), int(h * crop_frac)
    x0        = random.randint(0, w - cw)
    y0        = random.randint(0, h - ch)
    img       = img.crop((x0, y0, x0 + cw, y0 + ch))
    img       = img.resize((size, size), Image.LANCZOS)
    return img


def augment_one(img: Image.Image) -> Image.Image:
    """Apply a random chain of transforms to a PIL image."""
    img = _random_flip(img)
    img = _random_rotate(img)
    img = _random_color_jitter(img)
    img = _random_blur(img)
    img = _random_crop_resize(img, size=224)
    return img


# ──────────────────────────────────────────────
#  Per-class augmentation
# ──────────────────────────────────────────────

def count_originals(folder):
    return [f for f in os.listdir(folder)
            if os.path.splitext(f)[1].lower() in SUPPORTED_EXT
            and not f.startswith("aug_")]


def count_all(folder):
    return [f for f in os.listdir(folder)
            if os.path.splitext(f)[1].lower() in SUPPORTED_EXT]


def augment_class(folder, target_count, dry_run=False):
    originals = count_originals(folder)
    current   = count_all(folder)

    if len(current) >= target_count:
        print(f"  {os.path.basename(folder):40s}  already {len(current):5d} images — skip")
        return 0

    needed = target_count - len(current)
    print(f"  {os.path.basename(folder):40s}  "
          f"orig={len(originals):4d}  current={len(current):5d}  "
          f"need +{needed}")

    if dry_run:
        return needed

    generated = 0
    cycle     = list(originals)   # cycle through source images
    random.shuffle(cycle)
    src_idx   = 0

    while generated < needed:
        src_name  = cycle[src_idx % len(cycle)]
        src_idx  += 1
        src_path  = os.path.join(folder, src_name)

        try:
            img = Image.open(src_path).convert("RGB")
        except Exception as e:
            print(f"    Skipping {src_name}: {e}")
            continue

        aug_img  = augment_one(img)
        stem     = os.path.splitext(src_name)[0]
        out_name = f"aug_{generated:05d}_{stem}.jpg"
        out_path = os.path.join(folder, out_name)
        aug_img.save(out_path, "JPEG", quality=92)
        generated += 1

    print(f"    → generated {generated} augmented images")
    return generated


# ──────────────────────────────────────────────
#  Main
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Offline dataset augmentation")
    parser.add_argument("--target",  type=int, default=TARGET_TOTAL,
                        help=f"Target total images (default {TARGET_TOTAL})")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would be done, don't write files")
    args = parser.parse_args()

    if not os.path.isdir(IMAGE_DIR):
        print(f"ERROR: IMAGE_DIR not found: {IMAGE_DIR}")
        sys.exit(1)

    # List class folders
    class_folders = sorted([
        os.path.join(IMAGE_DIR, d)
        for d in os.listdir(IMAGE_DIR)
        if os.path.isdir(os.path.join(IMAGE_DIR, d))
    ])

    if not class_folders:
        print(f"ERROR: No subfolders found in {IMAGE_DIR}")
        sys.exit(1)

    n_classes      = len(class_folders)
    per_class_tgt  = args.target // n_classes
    remainder      = args.target - per_class_tgt * n_classes

    print(f"\nAugmentation plan")
    print(f"  Image dir      : {IMAGE_DIR}")
    print(f"  Classes found  : {n_classes}")
    print(f"  Target total   : {args.target:,}")
    print(f"  Per class      : {per_class_tgt:,}  "
          f"(+{remainder} extra spread across first {remainder} classes)")
    print(f"  Dry run        : {args.dry_run}\n")

    total_before  = sum(len(count_all(f)) for f in class_folders)
    total_written = 0

    for i, folder in enumerate(class_folders):
        tgt = per_class_tgt + (1 if i < remainder else 0)
        total_written += augment_class(folder, tgt, dry_run=args.dry_run)

    total_after = sum(len(count_all(f)) for f in class_folders)

    print(f"\nSummary")
    print(f"  Before : {total_before:,} images")
    if args.dry_run:
        print(f"  Would generate: {total_written:,} images")
        print(f"  After  : {total_before + total_written:,} images (estimated)")
    else:
        print(f"  Generated : {total_written:,} images")
        print(f"  After     : {total_after:,} images")
        print(f"\nDone. Re-run python train.py to start training on augmented data.")


if __name__ == "__main__":
    main()
