"""
Data loading for both modalities.

Image side   : SIPaKMeDStageDataset — remaps 5 SIPaKMeD classes → 3 stages
Clinical side: CSV → class-stratified pairing → limited SMOTE + class weights

Key changes vs original:
  - SMOTE target reduced from hard-2000 → 2× minority (no artificial inflation)
  - Clinical rows bucketed by risk score: Normal=low, LSIL=medium, HSIL=high
  - load_clinical_data_for_fusion() provides per-class clinical pools
  - Class imbalance handled by pos_weight in MLP loss, not heavy oversampling
"""

import os, pickle
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from torchvision import datasets, transforms
from sklearn.model_selection import train_test_split
from sklearn.preprocessing   import StandardScaler
from sklearn.impute           import SimpleImputer
from imblearn.over_sampling   import SMOTE

from config import (
    IMAGE_DIR, CLINICAL_CSV, MODELS_DIR,
    IMG_SIZE, BATCH_SIZE, SEED,
    SIPAK_TO_STAGE_IDX, NUM_STAGES,
    DROP_COLS, CLINICAL_TARGET,
)

# Maximum multiplier over natural minority count for SMOTE.
# 2.0 → minority class at most doubles. Never exceeds majority count.
# Original code hard-targeted 2000 samples regardless of real data size.
SMOTE_MAX_RATIO = 2.0


# ──────────────────────────────────────────────────────────
#  Image dataset  (unchanged from original)
# ──────────────────────────────────────────────────────────

class SIPaKMeDStageDataset(Dataset):
    """
    Wraps torchvision.ImageFolder.
    Remaps 5 SIPaKMeD cell-type labels → 3 clinical stage labels:
      Normal (0) | LSIL (1) | HSIL (2)
    """
    def __init__(self, root, transform):
        self.base    = datasets.ImageFolder(root=root, transform=transform)
        self.classes = ["Normal", "LSIL", "HSIL"]
        idx_to_folder = {v: k for k, v in self.base.class_to_idx.items()}
        self.targets  = [
            SIPAK_TO_STAGE_IDX.get(idx_to_folder[lbl], 0)
            for _, lbl in self.base.samples
        ]

    def __len__(self):
        return len(self.base)

    def __getitem__(self, idx):
        img, _ = self.base[idx]
        return img, self.targets[idx]


def get_loaders():
    """
    Returns train_loader, val_loader, class_weights tensor.
    80/20 deterministic split; WeightedRandomSampler on train.
    """
    train_tf = transforms.Compose([
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomVerticalFlip(),
        transforms.RandomRotation(40),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.1),
        transforms.RandomAffine(degrees=0, shear=10),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225]),
    ])
    val_tf = transforms.Compose([
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225]),
    ])

    full_train = SIPaKMeDStageDataset(IMAGE_DIR, train_tf)
    full_val   = SIPaKMeDStageDataset(IMAGE_DIR, val_tf)

    n       = len(full_train)
    indices = list(range(n))
    split   = int(0.2 * n)

    rng = np.random.default_rng(SEED)
    rng.shuffle(indices)
    train_idx, val_idx = indices[split:], indices[:split]

    train_set = torch.utils.data.Subset(full_train, train_idx)
    val_set   = torch.utils.data.Subset(full_val,   val_idx)

    stage_counts      = np.bincount(
        [full_train.targets[i] for i in train_idx], minlength=NUM_STAGES)
    weights_per_class = 1.0 / (stage_counts + 1e-6)
    sample_weights    = [weights_per_class[full_train.targets[i]]
                         for i in train_idx]
    sampler = WeightedRandomSampler(sample_weights, len(sample_weights))

    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE,
                              sampler=sampler,  num_workers=2, pin_memory=True)
    val_loader   = DataLoader(val_set,   batch_size=BATCH_SIZE,
                              shuffle=False,    num_workers=2, pin_memory=True)

    class_wts = torch.tensor(
        weights_per_class / weights_per_class.sum(), dtype=torch.float)

    total = len(full_train)
    print(f"Total images in dataset : {total}")
    print(f"Train: {len(train_set)}  Val: {len(val_set)}")
    print(f"Stage counts (train)    : {stage_counts}"
          f"  → run augment_dataset.py if total < 10 000")
    return train_loader, val_loader, class_wts


# ──────────────────────────────────────────────────────────
#  Clinical risk-score helper
# ──────────────────────────────────────────────────────────

def _compute_risk_score(df: pd.DataFrame) -> pd.Series:
    """
    Assigns a continuous risk score to each CSV row based on clinically
    meaningful columns. Used ONLY for bucketing rows into Normal/LSIL/HSIL
    pools — not for training.

    Weights are grounded in actual UCI dataset distributions:
      Biopsy=1 group had:
        • 2.3× more STDs (0.23 vs 0.10)
        • 2.3× higher STD count (0.38 vs 0.16)
        • HPV-linked diagnoses 7× more common (0.11 vs 0.015)
        • Slightly earlier first intercourse and more smokers

    Higher score → higher risk → HSIL bucket.
    IUD is mildly protective (negative weight).
    """
    s = pd.Series(np.zeros(len(df)), index=df.index)

    # Strongest signals (from biopsy=1 group analysis)
    if "STDs" in df.columns:
        s += df["STDs"].fillna(0) * 3.0
    if "STDs (number)" in df.columns:
        s += df["STDs (number)"].fillna(0) * 2.0
    if "STDs:HPV" in df.columns:
        s += df["STDs:HPV"].fillna(0) * 2.5
    if "Dx:HPV" in df.columns:
        s += df["Dx:HPV"].fillna(0) * 3.0
    if "Dx:CIN" in df.columns:
        s += df["Dx:CIN"].fillna(0) * 3.0
    if CLINICAL_TARGET in df.columns:
        # Biopsy-positive rows are pushed firmly into HSIL bucket
        s += df[CLINICAL_TARGET].fillna(0) * 4.0

    # Moderate signals
    if "First sexual intercourse" in df.columns:
        fsi = df["First sexual intercourse"].fillna(17)
        s += (fsi < 16).astype(float) * 2.0          # early → higher risk
    if "Smokes" in df.columns:
        s += df["Smokes"].fillna(0) * 1.5
    if "Number of sexual partners" in df.columns:
        s += (df["Number of sexual partners"].fillna(2) > 3).astype(float) * 1.5
    if "STDs:condylomatosis" in df.columns:
        s += df["STDs:condylomatosis"].fillna(0) * 1.5
    if "STDs:genital herpes" in df.columns:
        s += df["STDs:genital herpes"].fillna(0) * 1.5

    # Mild signals
    if "Age" in df.columns:
        age = df["Age"].fillna(26)
        s += ((age - 13) / (84 - 13)) * 1.0          # normalised, mild weight
    if "Hormonal Contraceptives" in df.columns:
        s += df["Hormonal Contraceptives"].fillna(0) * 0.5
    if "IUD" in df.columns:
        s -= df["IUD"].fillna(0) * 0.5                # mildly protective

    return s


def _stratify_clinical_rows(df: pd.DataFrame) -> dict:
    """
    Splits CSV rows into three risk buckets aligned with image classes:
      0 (Normal) → lowest-scoring third  (low-risk profiles)
      1 (LSIL)   → middle third          (medium-risk profiles)
      2 (HSIL)   → highest-scoring third (high-risk profiles)

    Uses tertile split so each bucket always has roughly equal size.
    Returns {stage_idx: DataFrame}.
    """
    scores   = _compute_risk_score(df)
    df       = df.copy()
    df["_s"] = scores

    low_cut  = scores.quantile(0.33)
    high_cut = scores.quantile(0.67)

    buckets = {
        0: df[scores <= low_cut].drop(columns=["_s"]),
        1: df[(scores > low_cut) & (scores <= high_cut)].drop(columns=["_s"]),
        2: df[scores > high_cut].drop(columns=["_s"]),
    }
    for stage, name in [(0, "Normal"), (1, "LSIL"), (2, "HSIL")]:
        print(f"  Clinical rows → {name:6s} bucket: {len(buckets[stage])}")
    return buckets


# ──────────────────────────────────────────────────────────
#  Clinical data pipeline
# ──────────────────────────────────────────────────────────

def _load_and_clean_csv():
    """Shared CSV loading + cleaning used by both pipeline functions."""
    df = pd.read_csv(CLINICAL_CSV)
    df.replace("?", np.nan, inplace=True)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Drop columns with >90% missing + configured DROP_COLS
    missing_frac = df.isnull().mean()
    high_missing = missing_frac[missing_frac > 0.90].index.tolist()
    drop = list(set(high_missing + [c for c in DROP_COLS if c in df.columns]))
    df.drop(columns=drop, inplace=True)
    return df, drop


def load_clinical_data():
    """
    Returns X_train, X_test, y_train, y_test, n_features.

    Pipeline:
      1. Load CSV, replace '?'→NaN, drop high-missing + DROP_COLS
      2. Impute (median) → StandardScale
      3. Train/test split FIRST (no leakage)
      4. Limited SMOTE: minority → at most SMOTE_MAX_RATIO × original count
         Remaining imbalance handled by pos_weight in BCEWithLogitsLoss
    """
    df, _ = _load_and_clean_csv()

    y = df[CLINICAL_TARGET].astype(int).values
    X = df.drop(columns=[CLINICAL_TARGET]).select_dtypes(include=[np.number])

    print(f"Clinical raw shape : {X.shape}")
    print(f"Class distribution : {np.bincount(y)}"
          f"  (neg={np.sum(y==0)}, pos={np.sum(y==1)})")

    imputer = SimpleImputer(strategy="median")
    X_imp   = imputer.fit_transform(X)
    scaler  = StandardScaler()
    X_sc    = scaler.fit_transform(X_imp)

    X_tr, X_te, y_tr, y_te = train_test_split(
        X_sc, y, test_size=0.2, random_state=SEED, stratify=y)

    # ── Limited SMOTE ────────────────────────────────────────
    n_min_orig  = int(np.sum(y_tr == 1))
    n_maj       = int(np.sum(y_tr == 0))
    smote_target = min(int(n_min_orig * SMOTE_MAX_RATIO), n_maj)
    k            = min(5, n_min_orig - 1)

    smote = SMOTE(
        random_state=SEED,
        k_neighbors=k,
        sampling_strategy={1: smote_target},
    )
    X_tr, y_tr = smote.fit_resample(X_tr, y_tr)
    print(f"After limited SMOTE: {X_tr.shape}  {np.bincount(y_tr)}")
    print(f"  minority {n_min_orig} → {smote_target}  "
          f"(capped at {SMOTE_MAX_RATIO}× original)")
    print(f"Final train : {X_tr.shape}  |  test: {X_te.shape}")

    # ── Persist artefacts ────────────────────────────────────
    os.makedirs(MODELS_DIR, exist_ok=True)
    pickle.dump(scaler,          open(f"{MODELS_DIR}/scaler.pkl",        "wb"))
    pickle.dump(imputer,         open(f"{MODELS_DIR}/imputer.pkl",       "wb"))
    pickle.dump(list(X.columns), open(f"{MODELS_DIR}/feature_names.pkl", "wb"))

    return X_tr, X_te, y_tr, y_te, X_tr.shape[1]


def load_clinical_data_for_fusion():
    """
    Returns class-stratified clinical feature vectors for Step 5 fusion.

    Instead of randomly sampling from the whole CSV (old behaviour),
    rows are bucketed by risk score so each image class is paired with a
    clinically consistent profile:
      Normal images  ← low-risk clinical rows
      LSIL images    ← medium-risk clinical rows
      HSIL images    ← high-risk clinical rows

    Returns:
      clinical_by_class : dict {stage_idx (0/1/2): np.ndarray (N, n_features)}
      n_features        : int

    Must be called AFTER load_clinical_data() so scaler/imputer are on disk.
    """
    df, drop = _load_and_clean_csv()

    print("Building class-stratified clinical buckets:")
    buckets = _stratify_clinical_rows(df)

    # Load artefacts fitted in load_clinical_data()
    for p in [f"{MODELS_DIR}/scaler.pkl",
              f"{MODELS_DIR}/imputer.pkl",
              f"{MODELS_DIR}/feature_names.pkl"]:
        if not os.path.exists(p):
            raise RuntimeError(
                f"{p} not found. Run load_clinical_data() (step 3) first.")

    scaler        = pickle.load(open(f"{MODELS_DIR}/scaler.pkl",        "rb"))
    imputer       = pickle.load(open(f"{MODELS_DIR}/imputer.pkl",       "rb"))
    feature_names = pickle.load(open(f"{MODELS_DIR}/feature_names.pkl", "rb"))

    clinical_by_class = {}
    for stage_idx, bucket_df in buckets.items():
        # Drop target + previously dropped columns
        drop_here = [c for c in [CLINICAL_TARGET] + drop
                     if c in bucket_df.columns]
        X_b = (bucket_df
               .drop(columns=drop_here, errors="ignore")
               .select_dtypes(include=[np.number]))

        # Align to training feature order (add missing cols as 0)
        for col in feature_names:
            if col not in X_b.columns:
                X_b[col] = 0.0
        X_b = X_b[feature_names]

        X_imp = imputer.transform(X_b)
        X_sc  = scaler.transform(X_imp)
        clinical_by_class[stage_idx] = X_sc

    n_features = len(feature_names)
    print(f"Stratified clinical features ready — n_features={n_features}")
    return clinical_by_class, n_features