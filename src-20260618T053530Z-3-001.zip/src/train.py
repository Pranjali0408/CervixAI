"""
Full PyTorch training pipeline — run: python train.py

Checkpointing: completed steps are saved to models/pipeline_state.json.
Re-running the script skips any step already marked done.

Flags:
  python train.py                  → resume from last checkpoint
  python train.py --force          → re-run everything from scratch
  python train.py --from-step 3    → re-run from step 3 onwards
  python train.py --only-step 5    → run only step 5
  python train.py --status         → print what is done and exit
"""

import os, sys, json, pickle, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.utils.class_weight import compute_class_weight
from sklearn.model_selection import train_test_split

from config   import (MODELS_DIR, REPORTS_DIR, EPOCHS_HEAD, EPOCHS_FINE,
                      LR_HEAD, LR_FINE, SEED, NUM_STAGES, STAGE_NAMES,
                      IMG_FEATURE_DIM, CLINICAL_FEAT_DIM, CNN_ARCHS)
from preprocess import get_loaders, load_clinical_data, load_clinical_data_for_fusion
from models   import CNNClassifier, ClinicalMLP, AttentionFusion
from evaluate import (plot_history, eval_classification, plot_confusion_matrix,
                      run_gradcam_batch, run_shap_analysis)

torch.manual_seed(SEED)
np.random.seed(SEED)
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {DEVICE}")

STATE_FILE = os.path.join(MODELS_DIR, "pipeline_state.json")


# ─────────────────────────────────────────────
#  Checkpoint helpers
# ─────────────────────────────────────────────

def load_state():
    os.makedirs(MODELS_DIR, exist_ok=True)
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}


def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def step_done(state, key):
    return state.get(key, {}).get("done", False)


def mark_done(state, key, **extra):
    state[key] = {"done": True, **extra}
    save_state(state)
    print(f"  [checkpoint] '{key}' saved.")


def print_state(state):
    print("\n── Pipeline state ─────────────────────────")
    if not state:
        print("  (no steps completed yet)")
    for k, v in state.items():
        done   = v.get("done", False)
        extras = {ek: ev for ek, ev in v.items() if ek != "done"}
        print(f"  {'[done]' if done else '[    ]'}  {k:26s}  {extras}")
    print("────────────────────────────────────────────\n")


# ─────────────────────────────────────────────
#  Generic train / eval loops
# ─────────────────────────────────────────────

def train_epoch(model, loader, criterion, optimizer):
    model.train()
    total_loss, correct, n = 0.0, 0, 0
    for imgs, labels in loader:
        imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
        optimizer.zero_grad()
        out  = model(imgs)
        loss = criterion(out, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * len(labels)
        correct    += (out.argmax(1) == labels).sum().item()
        n          += len(labels)
    return total_loss / n, correct / n


@torch.no_grad()
def eval_epoch(model, loader, criterion):
    model.eval()
    total_loss, correct, n = 0.0, 0, 0
    all_probs, all_preds, all_labels = [], [], []
    for imgs, labels in loader:
        imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
        out   = model(imgs)
        loss  = criterion(out, labels)
        probs = torch.softmax(out, dim=1)
        preds = out.argmax(1)
        total_loss += loss.item() * len(labels)
        correct    += (preds == labels).sum().item()
        n          += len(labels)
        all_probs.append(probs.cpu().numpy())
        all_preds.append(preds.cpu().numpy())
        all_labels.append(labels.cpu().numpy())
    return (total_loss / n, correct / n,
            np.vstack(all_probs),
            np.concatenate(all_preds),
            np.concatenate(all_labels))


def fit(model, train_loader, val_loader, criterion, optimizer, scheduler,
        epochs, name, patience=8):
    best_acc, wait = 0.0, 0
    history = {"train_loss": [], "val_loss": [],
               "train_acc":  [], "val_acc":  []}
    ckpt    = f"{MODELS_DIR}/{name}_best.pt"
    last    = (None, None, None)

    for epoch in range(1, epochs + 1):
        tr_loss, tr_acc = train_epoch(model, train_loader, criterion, optimizer)
        vl_loss, vl_acc, vl_probs, vl_preds, vl_lbls = eval_epoch(
            model, val_loader, criterion)

        if isinstance(scheduler, ReduceLROnPlateau):
            scheduler.step(vl_acc)
        else:
            scheduler.step()

        history["train_loss"].append(tr_loss)
        history["val_loss"].append(vl_loss)
        history["train_acc"].append(tr_acc)
        history["val_acc"].append(vl_acc)
        last = (vl_probs, vl_preds, vl_lbls)

        print(f"  Epoch {epoch:3d}/{epochs}  "
              f"loss={tr_loss:.4f}  acc={tr_acc:.4f}  "
              f"val_loss={vl_loss:.4f}  val_acc={vl_acc:.4f}")

        if vl_acc > best_acc:
            best_acc = vl_acc
            torch.save(model.state_dict(), ckpt)
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                print(f"  Early stop at epoch {epoch}")
                break

    model.load_state_dict(torch.load(ckpt, map_location=DEVICE))
    plot_history(history, name)
    return model, history, last[0], last[1], last[2]


# ─────────────────────────────────────────────
#  Step 1 — CNN comparison
# ─────────────────────────────────────────────

def run_cnn_comparison(train_loader, val_loader, class_wts, state):
    KEY = "step1_cnn_comparison"

    if step_done(state, KEY):
        print(f"\n[SKIP] Step 1 already done.")
        best_arch = state[KEY]["best_arch"]
        print(f"  Best arch from checkpoint: {best_arch}")
        return best_arch, state[KEY]["results"]

    print(f"\n{'='*52}\n  STEP 1 — CNN comparison\n{'='*52}")
    archs     = CNN_ARCHS
    criterion = nn.CrossEntropyLoss(weight=class_wts.to(DEVICE))

    comp_path = f"{REPORTS_DIR}/cnn_comparison.json"
    results   = {}
    if os.path.exists(comp_path):
        with open(comp_path) as f:
            results = json.load(f)
        print(f"  Partial results found: {list(results.keys())}")

    for arch in archs:
        pt_path = f"{MODELS_DIR}/{arch}_phase1.pt"
        if arch in results and os.path.exists(pt_path):
            print(f"\n  [SKIP] {arch} — already trained.")
            continue

        print(f"\n{'─'*52}\n  {arch.upper()} — frozen backbone\n{'─'*52}")
        model = CNNClassifier(arch, num_classes=NUM_STAGES,
                              freeze_backbone=True).to(DEVICE)
        head_params = (list(model.head.parameters()) +
                       list(model.classifier.parameters()))
        optimizer   = optim.Adam(head_params, lr=LR_HEAD)
        scheduler   = ReduceLROnPlateau(optimizer, mode="max",
                                        factor=0.3, patience=4)
        model, _, probs, preds, labels = fit(
            model, train_loader, val_loader, criterion,
            optimizer, scheduler, EPOCHS_HEAD, arch, patience=8
        )
        metrics = eval_classification(labels, preds, probs, STAGE_NAMES, arch)
        results[arch] = metrics
        torch.save(model.state_dict(), pt_path)
        print(f"  {arch} val accuracy: {metrics['accuracy']:.4f}")

        with open(comp_path, "w") as f:
            json.dump(results, f, indent=2)

    best_arch = max(results, key=lambda a: results[a]["accuracy"])
    print(f"\n  Best arch: {best_arch}  ({results[best_arch]['accuracy']:.4f})")
    mark_done(state, KEY, best_arch=best_arch, results=results)
    return best_arch, results


# ─────────────────────────────────────────────
#  Step 2 — Fine-tune best CNN
# ─────────────────────────────────────────────

def fine_tune_cnn(arch, train_loader, val_loader, class_wts, state):
    KEY = "step2_finetune"

    if step_done(state, KEY):
        print(f"\n[SKIP] Step 2 already done.")
        return _load_cnn(arch)

    print(f"\n{'='*52}\n  STEP 2 — Fine-tune {arch.upper()}\n{'='*52}")
    model = CNNClassifier(arch, num_classes=NUM_STAGES,
                          freeze_backbone=True).to(DEVICE)
    model.load_state_dict(
        torch.load(f"{MODELS_DIR}/{arch}_phase1.pt", map_location=DEVICE))
    model.unfreeze_top(30)

    criterion = nn.CrossEntropyLoss(weight=class_wts.to(DEVICE))
    optimizer = optim.Adam(
        filter(lambda p: p.requires_grad, model.parameters()), lr=LR_FINE)
    scheduler = CosineAnnealingLR(optimizer, T_max=EPOCHS_FINE, eta_min=1e-7)

    name  = f"{arch}_finetuned"
    model, _, probs, preds, labels = fit(
        model, train_loader, val_loader, criterion,
        optimizer, scheduler, EPOCHS_FINE, name, patience=10
    )
    metrics = eval_classification(labels, preds, probs, STAGE_NAMES, name)
    plot_confusion_matrix(labels, preds, STAGE_NAMES, name)
    torch.save(model.state_dict(), f"{MODELS_DIR}/{name}_final.pt")

    print("\n  Generating Grad-CAM visualisations (3 samples per class)...")
    try:
        _, val_loader_gc, _ = get_loaders()
        run_gradcam_batch(model, val_loader_gc, DEVICE,
                          n_per_class=3, save_dir=REPORTS_DIR)
    except Exception as e:
        print(f"  Grad-CAM skipped: {e}")

    mark_done(state, KEY, arch=arch,
              val_accuracy=metrics["accuracy"],
              auc=metrics.get("auc"))
    return model


def _load_cnn(arch):
    model = CNNClassifier(arch, num_classes=NUM_STAGES,
                          freeze_backbone=False).to(DEVICE)
    for suffix in ["_finetuned_final.pt", "_finetuned_best.pt", "_phase1.pt"]:
        p = f"{MODELS_DIR}/{arch}{suffix}"
        if os.path.exists(p):
            model.load_state_dict(torch.load(p, map_location=DEVICE))
            model.eval()
            print(f"  Loaded CNN from {p}")
            return model
    raise FileNotFoundError(f"No weights found for {arch}")


# ─────────────────────────────────────────────
#  Step 3 — Train clinical MLP
# ─────────────────────────────────────────────

def train_mlp(X_tr, y_tr, X_te, y_te, n_feat, state):
    KEY = "step3_mlp"

    if step_done(state, KEY):
        print(f"\n[SKIP] Step 3 already done.")
        model = ClinicalMLP(n_feat).to(DEVICE)
        model.load_state_dict(
            torch.load(f"{MODELS_DIR}/clinical_mlp_best.pt",
                       map_location=DEVICE))
        model.eval()
        return model

    print(f"\n{'='*52}\n  STEP 3 — Clinical MLP\n{'='*52}")
    model  = ClinicalMLP(n_feat).to(DEVICE)
    cw     = compute_class_weight("balanced",
                                   classes=np.unique(y_tr), y=y_tr)
    pos_wt = torch.tensor([cw[1] / cw[0]], dtype=torch.float).to(DEVICE)
    crit   = nn.BCEWithLogitsLoss(pos_weight=pos_wt)
    opt    = optim.Adam(model.parameters(), lr=1e-3)
    sched  = ReduceLROnPlateau(opt, mode="max", factor=0.3, patience=6)

    X_tr_t = torch.tensor(X_tr, dtype=torch.float32)
    y_tr_t = torch.tensor(y_tr, dtype=torch.float32)
    X_te_t = torch.tensor(X_te, dtype=torch.float32)
    y_te_t = torch.tensor(y_te, dtype=torch.float32)

    best_auc, patience, wait = 0.0, 10, 0
    history = {"train_loss": [], "val_loss": [],
               "train_acc":  [], "val_acc":  []}

    for epoch in range(1, 81):
        model.train()
        opt.zero_grad()
        out  = model(X_tr_t.to(DEVICE))
        loss = crit(out, y_tr_t.to(DEVICE))
        loss.backward(); opt.step()

        model.eval()
        with torch.no_grad():
            vl_out  = model(X_te_t.to(DEVICE))
            vl_loss = crit(vl_out, y_te_t.to(DEVICE)).item()
            vl_prob = torch.sigmoid(vl_out).cpu().numpy()
            vl_pred = (vl_prob >= 0.5).astype(int)
            try:
                auc = roc_auc_score(y_te, vl_prob)
            except Exception:
                auc = 0.5
            acc = accuracy_score(y_te, vl_pred)

        sched.step(auc)
        tr_pred = (torch.sigmoid(out).detach().cpu().numpy() >= 0.5)
        history["train_loss"].append(loss.item())
        history["val_loss"].append(vl_loss)
        history["train_acc"].append(accuracy_score(y_tr, tr_pred))
        history["val_acc"].append(acc)

        if epoch % 10 == 0:
            print(f"  Epoch {epoch:3d}  loss={loss.item():.4f}  "
                  f"val_acc={acc:.4f}  auc={auc:.4f}")

        if auc > best_auc:
            best_auc = auc
            torch.save(model.state_dict(),
                       f"{MODELS_DIR}/clinical_mlp_best.pt")
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                print(f"  Early stop at epoch {epoch}")
                break

    model.load_state_dict(
        torch.load(f"{MODELS_DIR}/clinical_mlp_best.pt", map_location=DEVICE))
    plot_history(history, "clinical_mlp")

    print("\n  Running SHAP analysis on clinical MLP...")
    try:
        feat_names = pickle.load(open(f"{MODELS_DIR}/feature_names.pkl", "rb"))
        run_shap_analysis(model, X_tr, X_te, feat_names,
                          DEVICE, save_dir=REPORTS_DIR)
    except Exception as e:
        print(f"  SHAP skipped: {e}")

    # Save background data for per-patient SHAP at inference time
    # The /shap endpoint in app.py needs this to initialise DeepExplainer
    np.savez(f"{MODELS_DIR}/shap_background.npz", X_train=X_tr)
    print(f"  SHAP background saved: {X_tr.shape}")

    mark_done(state, KEY, best_auc=round(best_auc, 4))
    return model


# ─────────────────────────────────────────────
#  Step 4 — Extract and cache feature vectors
# ─────────────────────────────────────────────

@torch.no_grad()
def _extract_img_feats(cnn_model, loader):
    cnn_model.eval()
    all_feats, all_labels = [], []
    for imgs, labels in loader:
        feats = cnn_model.forward_features(imgs.to(DEVICE))
        all_feats.append(feats.cpu().numpy())
        all_labels.append(labels.numpy())
    feats  = np.vstack(all_feats)
    labels = np.concatenate(all_labels)
    print(f"  Image features: {feats.shape}  "
          f"stages: {np.bincount(labels, minlength=NUM_STAGES)}")
    return feats, labels


@torch.no_grad()
def _extract_one_clinical_feature(mlp_model, row_np):
    """Extract 32-dim feature vector for a single clinical row."""
    mlp_model.eval()
    t = torch.tensor(row_np, dtype=torch.float32).unsqueeze(0).to(DEVICE)
    return mlp_model.forward_features(t).cpu().numpy().squeeze(0)


def extract_and_cache(best_cnn, mlp_model, state):
    """
    Step 4: extract image feature vectors and cache to disk.
    clinical pairing is done in train_fusion (step 5) using stratified pools.
    """
    KEY        = "step4_features"
    feats_path = f"{MODELS_DIR}/img_feats.npz"

    if step_done(state, KEY) and os.path.exists(feats_path):
        print(f"\n[SKIP] Step 4 already done — loading cached features.")
        data = np.load(feats_path)
        return data["img_feats"], data["y_img"]

    print(f"\n{'='*52}\n  STEP 4 — Feature extraction\n{'='*52}")
    train_loader, _, _ = get_loaders()
    img_feats, y_img   = _extract_img_feats(best_cnn, train_loader)
    np.savez(feats_path, img_feats=img_feats, y_img=y_img)
    mark_done(state, KEY, img_shape=list(img_feats.shape))
    return img_feats, y_img


# ─────────────────────────────────────────────
#  Step 5 — Attention fusion
# ─────────────────────────────────────────────

def train_fusion(img_feats, y_img, clinical_by_class, mlp_model, state):
    """
    clinical_by_class: dict {stage_idx: np.ndarray (N_rows, n_raw_features)}
      Each image is paired with a randomly sampled clinical row from the
      pool that matches its class — not from the whole CSV at random.

      Normal  image → low-risk clinical profile
      LSIL    image → medium-risk clinical profile
      HSIL    image → high-risk clinical profile
    """
    KEY = "step5_fusion"

    if step_done(state, KEY):
        print(f"\n[SKIP] Step 5 already done.")
        model = AttentionFusion(IMG_FEATURE_DIM, CLINICAL_FEAT_DIM,
                                NUM_STAGES).to(DEVICE)
        model.load_state_dict(
            torch.load(f"{MODELS_DIR}/fusion_model_final.pt",
                       map_location=DEVICE))
        model.eval()
        return model

    print(f"\n{'='*52}\n  STEP 5 — Attention fusion (stratified pairing)\n{'='*52}")
    from torch.utils.data import TensorDataset, DataLoader as DL

    # ── Build class-stratified clinical feature matrix ────────
    rng         = np.random.default_rng(SEED)
    clin_paired = np.zeros((len(img_feats), CLINICAL_FEAT_DIM), dtype=np.float32)

    for i, stage in enumerate(y_img):
        stage = int(stage)
        pool  = clinical_by_class[stage]          # rows matching image class
        row   = pool[rng.integers(len(pool))]     # random row from that pool
        clin_paired[i] = _extract_one_clinical_feature(mlp_model, row)

    print(f"  Paired {len(img_feats)} images with class-matched clinical features.")
    for s, name in [(0, "Normal"), (1, "LSIL"), (2, "HSIL")]:
        count = int(np.sum(y_img == s))
        pool_size = len(clinical_by_class[s])
        print(f"    {name:6s}: {count} images ← pool of {pool_size} clinical rows")

    # ── Train/test split ──────────────────────────────────────
    Xi_tr, Xi_te, Xc_tr, Xc_te, y_tr, y_te = train_test_split(
        img_feats, clin_paired, y_img,
        test_size=0.2, random_state=SEED, stratify=y_img
    )
    cw   = compute_class_weight("balanced", classes=np.unique(y_tr), y=y_tr)
    cw_t = torch.tensor(cw, dtype=torch.float).to(DEVICE)

    def make_loader(Xi, Xc, y, shuffle):
        ds = TensorDataset(
            torch.tensor(Xi, dtype=torch.float32),
            torch.tensor(Xc, dtype=torch.float32),
            torch.tensor(y,  dtype=torch.long),
        )
        return DL(ds, batch_size=64, shuffle=shuffle)

    tr_dl  = make_loader(Xi_tr, Xc_tr, y_tr, True)
    te_dl  = make_loader(Xi_te, Xc_te, y_te, False)
    model  = AttentionFusion(IMG_FEATURE_DIM, CLINICAL_FEAT_DIM,
                              NUM_STAGES).to(DEVICE)
    crit   = nn.CrossEntropyLoss(weight=cw_t)
    opt    = optim.Adam(model.parameters(), lr=5e-4)
    sched  = CosineAnnealingLR(opt, T_max=60, eta_min=1e-7)

    best_acc, patience, wait = 0.0, 10, 0
    history = {"train_loss": [], "val_loss": [],
               "train_acc":  [], "val_acc":  []}
    last_p = last_prob = last_y = None

    for epoch in range(1, 61):
        model.train()
        tr_loss, tr_cor, n = 0.0, 0, 0
        for xi, xc, yb in tr_dl:
            xi, xc, yb = xi.to(DEVICE), xc.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            out = model(xi, xc); loss = crit(out, yb)
            loss.backward(); opt.step()
            tr_loss += loss.item() * len(yb)
            tr_cor  += (out.argmax(1) == yb).sum().item()
            n       += len(yb)
        sched.step()

        model.eval()
        vl_loss, vl_cor, vn = 0.0, 0, 0
        ep, eprob, ey = [], [], []
        with torch.no_grad():
            for xi, xc, yb in te_dl:
                xi, xc, yb = xi.to(DEVICE), xc.to(DEVICE), yb.to(DEVICE)
                out = model(xi, xc); loss = crit(out, yb)
                vl_loss += loss.item() * len(yb)
                vl_cor  += (out.argmax(1) == yb).sum().item()
                vn      += len(yb)
                ep.append(out.argmax(1).cpu().numpy())
                eprob.append(torch.softmax(out, 1).cpu().numpy())
                ey.append(yb.cpu().numpy())

        tr_a = tr_cor / n; vl_a = vl_cor / vn
        history["train_loss"].append(tr_loss / n)
        history["val_loss"].append(vl_loss / vn)
        history["train_acc"].append(tr_a)
        history["val_acc"].append(vl_a)
        last_p    = np.concatenate(ep)
        last_prob = np.vstack(eprob)
        last_y    = np.concatenate(ey)

        if epoch % 10 == 0:
            print(f"  Epoch {epoch:3d}  "
                  f"loss={tr_loss/n:.4f}  acc={tr_a:.4f}  val_acc={vl_a:.4f}")

        if vl_a > best_acc:
            best_acc = vl_a
            torch.save(model.state_dict(),
                       f"{MODELS_DIR}/fusion_model_best.pt")
            wait = 0
        else:
            wait += 1
            if wait >= patience: break

    model.load_state_dict(
        torch.load(f"{MODELS_DIR}/fusion_model_best.pt", map_location=DEVICE))
    metrics = eval_classification(last_y, last_p, last_prob, STAGE_NAMES, "fusion")
    plot_confusion_matrix(last_y, last_p, STAGE_NAMES, "fusion")
    plot_history(history, "fusion_model")
    torch.save(model.state_dict(), f"{MODELS_DIR}/fusion_model_final.pt")
    mark_done(state, KEY,
              val_accuracy=metrics["accuracy"], auc=metrics.get("auc"))
    return model


# ─────────────────────────────────────────────
#  CLI + MAIN
# ─────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="Cervical cancer training pipeline")
    p.add_argument("--force",      action="store_true",
                   help="Re-run all steps from scratch")
    p.add_argument("--from-step",  type=int, default=None, metavar="N",
                   help="Re-run from step N (1-5), skip earlier steps")
    p.add_argument("--only-step",  type=int, default=None, metavar="N",
                   help="Run only step N (1-5)")
    p.add_argument("--status",     action="store_true",
                   help="Print pipeline state and exit")
    return p.parse_args()


if __name__ == "__main__":
    args  = parse_args()
    state = load_state()

    if args.status:
        print_state(state)
        sys.exit(0)

    if args.force:
        print("--force: clearing all checkpoints and restarting.")
        state = {}
        save_state(state)

    if args.from_step:
        step_keys = ["step1_cnn_comparison", "step2_finetune",
                     "step3_mlp", "step4_features", "step5_fusion"]
        for k in step_keys[args.from_step - 1:]:
            state.pop(k, None)
        save_state(state)
        print(f"--from-step {args.from_step}: cleared steps {args.from_step}–5.")

    print_state(state)

    def get_best_arch():
        if "step1_cnn_comparison" in state:
            return state["step1_cnn_comparison"].get("best_arch", "resnet50")
        p = f"{MODELS_DIR}/best_arch.pkl"
        if os.path.exists(p):
            return pickle.load(open(p, "rb"))
        return "resnet50"

    run = lambda s: (args.only_step is None or args.only_step == s)

    # ── Step 1 ─────────────────────────────────────────────
    if run(1):
        train_loader, val_loader, class_wts = get_loaders()
        best_arch, _ = run_cnn_comparison(
            train_loader, val_loader, class_wts, state)
    else:
        best_arch = get_best_arch()
        train_loader = val_loader = class_wts = None

    # ── Step 2 ─────────────────────────────────────────────
    if run(2):
        if train_loader is None:
            train_loader, val_loader, class_wts = get_loaders()
        best_cnn = fine_tune_cnn(
            best_arch, train_loader, val_loader, class_wts, state)
    else:
        best_cnn = _load_cnn(best_arch)

    # ── Step 3 ─────────────────────────────────────────────
    X_tr, X_te, y_tr, y_te, n_feat = load_clinical_data()
    if run(3):
        mlp = train_mlp(X_tr, y_tr, X_te, y_te, n_feat, state)
    else:
        mlp = ClinicalMLP(n_feat).to(DEVICE)
        mlp.load_state_dict(
            torch.load(f"{MODELS_DIR}/clinical_mlp_best.pt",
                       map_location=DEVICE))
        mlp.eval()

    # ── Step 4 ─────────────────────────────────────────────
    # Note: signature changed — no longer needs X_tr/X_te
    if run(4) or run(5):
        img_feats, y_img = extract_and_cache(best_cnn, mlp, state)

    # ── Step 5 ─────────────────────────────────────────────
    # Load stratified clinical pools (requires step 3 scaler on disk)
    if run(5):
        clinical_by_class, _ = load_clinical_data_for_fusion()
        train_fusion(img_feats, y_img, clinical_by_class, mlp, state)

    pickle.dump(best_arch, open(f"{MODELS_DIR}/best_arch.pkl", "wb"))
    print("\n" + "="*52 + "\n  Pipeline complete.\n" + "="*52)
    print_state(state)