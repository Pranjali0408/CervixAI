
"""
Evaluation, explainability, and visualisation utilities.

  plot_history()           — accuracy + loss curves
  eval_classification()    — accuracy, precision, recall, F1, AUC-ROC
  plot_confusion_matrix()  — heatmap + per-class recall annotations
  run_gradcam_batch()      — Grad-CAM on N samples per class (Point 9)
  run_shap_analysis()      — SHAP waterfall + summary for clinical MLP (Point 9)
"""

import os, json
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import torch
import torch.nn as nn

from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, precision_recall_fscore_support, roc_auc_score,
)
from config import REPORTS_DIR, STAGE_NAMES

os.makedirs(REPORTS_DIR, exist_ok=True)


# ─────────────────────────────────────────
#  Training curves
# ─────────────────────────────────────────

def plot_history(history: dict, name: str):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    for ax, tr_key, vl_key, title in [
        (axes[0], "train_acc",  "val_acc",  "Accuracy"),
        (axes[1], "train_loss", "val_loss", "Loss"),
    ]:
        if tr_key in history and history[tr_key]:
            ax.plot(history[tr_key], label="Train")
            ax.plot(history[vl_key], label="Val")
        ax.set_title(f"{name} — {title}")
        ax.set_xlabel("Epoch"); ax.legend()
    plt.tight_layout()
    plt.savefig(f"{REPORTS_DIR}/{name}_curves.png", dpi=150)
    plt.close()


# ─────────────────────────────────────────
#  Classification metrics
# ─────────────────────────────────────────

def eval_classification(y_true, y_pred, y_prob, class_names, name):
    acc           = accuracy_score(y_true, y_pred)
    p, r, f1, _   = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0)

    auc = None
    if y_prob is not None:
        try:
            auc = roc_auc_score(y_true, y_prob,
                                multi_class="ovr", average="macro")
        except Exception:
            pass

    report = classification_report(
        y_true, y_pred, target_names=class_names, zero_division=0)

    bar = "─" * 52
    print(f"\n{bar}  {name}")
    print(f"  Accuracy : {acc:.4f}   Macro-F1  : {f1:.4f}")
    print(f"  Recall   : {r:.4f}   Precision : {p:.4f}")
    if auc:
        print(f"  AUC-ROC  : {auc:.4f}")
    print(f"{bar}\n{report}")

    metrics = dict(accuracy=round(acc,4), f1=round(f1,4),
                   recall=round(r,4), precision=round(p,4))
    if auc:
        metrics["auc"] = round(auc, 4)

    with open(f"{REPORTS_DIR}/{name}_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    with open(f"{REPORTS_DIR}/{name}_report.txt", "w") as f:
        f.write(report)
    return metrics


def plot_confusion_matrix(y_true, y_pred, class_names, name):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=class_names, yticklabels=class_names)
    plt.title(f"Confusion matrix — {name}")
    plt.ylabel("True"); plt.xlabel("Predicted")
    plt.tight_layout()
    plt.savefig(f"{REPORTS_DIR}/{name}_confusion_matrix.png", dpi=150)
    plt.close()


# ─────────────────────────────────────────
#  Grad-CAM  (Point 9)
# ─────────────────────────────────────────

class _GradCAMHook:
    """Registers forward + backward hooks on a target layer."""
    def __init__(self, layer):
        self.acts  = None
        self.grads = None
        self._fh   = layer.register_forward_hook(self._save_acts)
        self._bh   = layer.register_full_backward_hook(self._save_grads)

    def _save_acts(self, m, inp, out):
        self.acts = out.detach()

    def _save_grads(self, m, grad_in, grad_out):
        self.grads = grad_out[0].detach()

    def remove(self):
        self._fh.remove()
        self._bh.remove()


# def _compute_cam(hook: _GradCAMHook, h: int, w: int) -> np.ndarray:
#     """Pool gradients → weighted sum of activations → ReLU → resize."""
#     import cv2
#     grads   = hook.grads.cpu().numpy()     # (C, Hf, Wf)
#     acts    = hook.acts.cpu().numpy()      # (C, Hf, Wf)
#     weights = grads.mean(axis=(1, 2))      # (C,)
#     cam     = np.maximum((weights[:, None, None] * acts).sum(0), 0)
#     cam    /= (cam.max() + 1e-8)
#     cam     = cv2.resize(cam, (w, h))
#     return cam

def _compute_cam(hook: _GradCAMHook, h: int, w: int) -> np.ndarray:
    """Pool gradients -> weighted sum of activations -> ReLU -> resize."""
    import cv2

    grads = hook.grads.detach().cpu().numpy()
    acts  = hook.acts.detach().cpu().numpy()

    # Remove batch dimension: (1, C, Hf, Wf) -> (C, Hf, Wf)
    if grads.ndim == 4:
        grads = grads[0]
    if acts.ndim == 4:
        acts = acts[0]

    # Channel-wise weights
    weights = grads.mean(axis=(1, 2))  # (C,)

    # Weighted combination of activations
    cam = np.maximum((weights[:, None, None] * acts).sum(axis=0), 0)

    # Normalize safely
    cam_max = cam.max()
    if cam_max > 0:
        cam = cam / cam_max
    else:
        cam = np.zeros_like(cam, dtype=np.float32)

    # Resize and force proper OpenCV input type
    cam = cv2.resize(cam.astype(np.float32), (w, h))
    return cam




def _overlay_cam(orig_rgb: np.ndarray, cam: np.ndarray) -> np.ndarray:
    """Blend Grad-CAM heatmap over the original image."""
    import cv2
    hm      = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(orig_rgb, 0.6, hm[:, :, ::-1], 0.4, 0)
    return overlay


def gradcam_single(model, img_tensor: torch.Tensor,
                   class_idx: int = None) -> tuple:
    """
    Generate Grad-CAM for one image.

    Args:
        model      : CNNClassifier (must implement get_gradcam_layer())
        img_tensor : (1, 3, H, W) normalised tensor
        class_idx  : class to explain; None → argmax of prediction

    Returns:
        (cam_array, predicted_class_idx)
    """
    target_layer = model.get_gradcam_layer()
    if target_layer is None:
        raise RuntimeError("Model did not return a Grad-CAM target layer.")

    hook  = _GradCAMHook(target_layer)
    model.eval()

    img_tensor = img_tensor.clone().requires_grad_(True)
    out        = model(img_tensor)

    if class_idx is None:
        class_idx = int(out.argmax(1).item())

    model.zero_grad()
    out[0, class_idx].backward()

    h, w = img_tensor.shape[2], img_tensor.shape[3]
    cam  = _compute_cam(hook, h, w)
    hook.remove()
    return cam, class_idx


def run_gradcam_batch(model, val_loader, device,
                      n_per_class: int = 3,
                      save_dir: str = None):
    """
    Generate Grad-CAM overlays for n_per_class images from each stage.
    Saves a grid PNG per class to reports/gradcam_{stage}.png.

    Point 9 requirement: Grad-CAM highlights important cell regions.
    """
    if save_dir is None:
        save_dir = REPORTS_DIR
    os.makedirs(save_dir, exist_ok=True)

    mean = np.array([0.485, 0.456, 0.406])
    std  = np.array([0.229, 0.224, 0.225])

    # Collect images per class
    buckets = {i: [] for i in range(len(STAGE_NAMES))}
    model.eval()
    model.to(device)

    for imgs, labels in val_loader:
        for img, lbl in zip(imgs, labels):
            lbl = int(lbl)
            if len(buckets[lbl]) < n_per_class:
                buckets[lbl].append(img)
        if all(len(v) >= n_per_class for v in buckets.values()):
            break

    # Generate and save per class
    for cls_idx, stage_name in enumerate(STAGE_NAMES):
        imgs_list = buckets.get(cls_idx, [])
        if not imgs_list:
            print(f"  Grad-CAM: no images collected for {stage_name}")
            continue

        n   = len(imgs_list)
        fig, axes = plt.subplots(n, 2, figsize=(6, 3 * n))
        if n == 1:
            axes = [axes]

        for row, img_t in enumerate(imgs_list):
            img_batch = img_t.unsqueeze(0).to(device)
            try:
                cam, pred = gradcam_single(model, img_batch, class_idx=cls_idx)
            except Exception as e:
                print(f"  Grad-CAM error for {stage_name}: {e}")
                continue

            orig = img_t.permute(1, 2, 0).cpu().numpy()
            orig = np.clip(orig * std + mean, 0, 1)
            orig_u8  = np.uint8(orig * 255)
            overlay  = _overlay_cam(orig_u8, cam)

            axes[row][0].imshow(orig_u8)
            axes[row][0].set_title(f"Original — {stage_name}")
            axes[row][0].axis("off")
            axes[row][1].imshow(overlay)
            axes[row][1].set_title(f"Grad-CAM (pred={STAGE_NAMES[pred]})")
            axes[row][1].axis("off")

        plt.suptitle(f"Grad-CAM — {stage_name}", fontsize=13, y=1.01)
        plt.tight_layout()
        out_path = os.path.join(save_dir, f"gradcam_{stage_name}.png")
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"  Grad-CAM saved → {out_path}")


# ─────────────────────────────────────────
#  SHAP — clinical MLP  (Point 9)
# ─────────────────────────────────────────

def run_shap_analysis(mlp_model, X_train: np.ndarray, X_test: np.ndarray,
                      feature_names: list, device, save_dir: str = None):
    """
    Run SHAP analysis on the clinical MLP.

    Produces:
      shap_summary.png     — bar chart of mean |SHAP| per feature
      shap_beeswarm.png    — beeswarm / dot plot showing direction of impact
      shap_waterfall_N.png — per-sample waterfall for first 3 test samples

    Point 9 requirement: SHAP explains which clinical risk factors drive predictions.
    """
    if save_dir is None:
        save_dir = REPORTS_DIR
    os.makedirs(save_dir, exist_ok=True)

    try:
        import shap
    except ImportError:
        print("  SHAP not installed. Run: pip install shap")
        return

    mlp_model.eval()
    mlp_model.to(device)

    # ── DeepExplainer (much faster than KernelExplainer for PyTorch) ───────
    # Background = random 100-sample subset of training data
    rng  = np.random.default_rng(42)
    idx  = rng.choice(len(X_train), size=min(100, len(X_train)), replace=False)
    bg   = torch.tensor(X_train[idx], dtype=torch.float32).to(device)

    # Patch inplace activations — SHAP DeepExplainer's backward hooks are
    # incompatible with inplace=True ReLU and raise RuntimeError.
    for child in mlp_model.modules():
        if hasattr(child, "inplace"):
            child.inplace = False

    # Wrap model so DeepExplainer gets probabilities (sigmoid output).
    # Output MUST be (batch, 1) — not (batch,).  SHAP's DeepExplainer
    # internally does output.shape[1] to count outputs; a 1-D output
    # raises "tuple index out of range" inside SHAP.
    # The resulting SHAP values will be (n_samples, n_features, 1) in
    # newer SHAP — we squeeze that trailing dim below.
    class _SigmoidWrapper(nn.Module):
        def __init__(self, m): super().__init__(); self.m = m
        def forward(self, x): return torch.sigmoid(self.m(x)).unsqueeze(1)  # → (batch, 1)

    wrapped    = _SigmoidWrapper(mlp_model).to(device)
    explainer  = shap.DeepExplainer(wrapped, bg)

    # Explain first 50 test samples (fast)
    X_exp   = torch.tensor(X_test[:50], dtype=torch.float32).to(device)
    # check_additivity=False suppresses the rounding-error warning that fires
    # when sigmoid squashes outputs near 0/1.
    sv      = explainer.shap_values(X_exp, check_additivity=False)
    # Older SHAP: list[array(n_samples, n_features)]  → sv[0] = (50, 33)
    # Newer SHAP: array(n_samples, n_features, 1)     → squeeze → (50, 33)
    sv_np   = sv[0] if isinstance(sv, list) else sv
    sv_np   = np.squeeze(sv_np)   # drop trailing size-1 dim → (50, 33)

    # ── Summary bar plot ──────────────────────────────────────────────────
    plt.figure(figsize=(10, 6))
    shap.summary_plot(sv_np, X_test[:50],
                      feature_names=feature_names,
                      plot_type="bar", show=False)
    plt.title("SHAP — mean |value| per clinical feature")
    plt.tight_layout()
    p = os.path.join(save_dir, "shap_summary_bar.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close()
    print(f"  SHAP summary bar  → {p}")

    # ── Beeswarm / dot plot ───────────────────────────────────────────────
    plt.figure(figsize=(10, 7))
    shap.summary_plot(sv_np, X_test[:50],
                      feature_names=feature_names,
                      plot_type="dot", show=False)
    plt.title("SHAP beeswarm — direction and magnitude")
    plt.tight_layout()
    p = os.path.join(save_dir, "shap_beeswarm.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close()
    print(f"  SHAP beeswarm     → {p}")

    # ── Per-sample waterfall (first 3 test samples) ───────────────────────
    for i in range(min(3, len(X_test))):
        try:
            exp_obj = shap.Explanation(
                values        = np.squeeze(sv_np[i]),   # ensure 1-D (n_features,)
                base_values   = explainer.expected_value[0]
                                if isinstance(explainer.expected_value, (list, np.ndarray))
                                else float(explainer.expected_value),
                data          = X_test[i],
                feature_names = feature_names,
            )
            plt.figure(figsize=(10, 5))
            shap.plots.waterfall(exp_obj, show=False)
            plt.title(f"SHAP waterfall — sample {i}")
            plt.tight_layout()
            p = os.path.join(save_dir, f"shap_waterfall_{i}.png")
            plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close()
            print(f"  SHAP waterfall {i}  → {p}")
        except Exception as e:
            print(f"  Waterfall {i} skipped: {e}")

    # ── Save top-10 features by mean |SHAP| as JSON ───────────────────────
    mean_abs = np.abs(sv_np).mean(axis=0)
    ranked   = sorted(zip(feature_names, mean_abs.tolist()),
                      key=lambda x: x[1], reverse=True)
    top10    = ranked[:10]
    p        = os.path.join(save_dir, "shap_top10_features.json")
    with open(p, "w") as f:
        json.dump(top10, f, indent=2)
    print(f"  SHAP top-10       → {p}")
    print(f"\n  Top 10 clinical risk factors (by SHAP):")
    for feat, val in top10:
        print(f"    {feat:40s}  {val:.5f}")


# ─────────────────────────────────────────
#  SHAP — single real-time prediction
# ─────────────────────────────────────────

def shap_single_prediction(mlp_model, X_background: np.ndarray,
                            x_patient: np.ndarray,
                            feature_names: list,
                            device) -> str:
    """
    Compute a SHAP waterfall explanation for ONE patient row at inference time.

    This is the per-analysis SHAP — called by the Flask /shap endpoint when
    a user submits clinical inputs. It explains WHY the model gave this
    specific patient their risk score, not aggregate dataset statistics.

    Args:
        mlp_model     : trained ClinicalMLP (already on device)
        X_background  : np.ndarray (N, n_features) — background dataset
                        (the scaled training data, loaded from disk)
        x_patient     : np.ndarray (1, n_features) — this patient's scaled features
        feature_names : list of column names
        device        : torch.device

    Returns:
        base64-encoded PNG string of the waterfall plot (no prefix).
    """
    import shap, io, base64

    mlp_model.eval()
    mlp_model.to(device)

    # ── Patch: SHAP DeepExplainer installs backward hooks that are
    #    incompatible with inplace ReLU (raises RuntimeError about views
    #    being modified inplace inside a custom Function).  Replace every
    #    inplace activation in the model with an out-of-place equivalent
    #    before building the explainer.
    def _disable_inplace(module: nn.Module) -> None:
        for child in module.modules():
            if hasattr(child, "inplace"):
                child.inplace = False

    _disable_inplace(mlp_model)

    class _SigmoidWrapper(nn.Module):
        def __init__(self, m): super().__init__(); self.m = m
        # Must return (batch, 1) — SHAP's DeepExplainer does output.shape[1]
        # internally; a 1-D (batch,) output raises "tuple index out of range".
        # The (batch, 1) makes newer SHAP return values shaped
        # (n_samples, n_features, 1) which we squeeze below.
        def forward(self, x): return torch.sigmoid(self.m(x)).unsqueeze(1)  # → (batch, 1)

    wrapped = _SigmoidWrapper(mlp_model).to(device)

    # Use a small random background (100 rows max) for speed
    rng = np.random.default_rng(0)
    idx = rng.choice(len(X_background),
                     size=min(100, len(X_background)), replace=False)
    bg  = torch.tensor(X_background[idx], dtype=torch.float32).to(device)

    explainer = shap.DeepExplainer(wrapped, bg)

    x_t  = torch.tensor(x_patient, dtype=torch.float32).to(device)
    # check_additivity=False suppresses rounding-error warnings from sigmoid.
    sv    = explainer.shap_values(x_t, check_additivity=False)
    # Older SHAP: list[array]; newer SHAP: array directly.
    # Either way we want shape (1, n_features).
    sv_np = sv[0] if isinstance(sv, list) else sv
    sv_np = np.squeeze(sv_np)          # → (n_features,)
    if sv_np.ndim == 1:                # ensure (1, n_features) for indexing below
        sv_np = sv_np[np.newaxis, :]   # → (1, n_features)

    base_val = explainer.expected_value
    if isinstance(base_val, (list, np.ndarray)):
        base_val = float(base_val[0])
    else:
        base_val = float(base_val)

    exp_obj = shap.Explanation(
        values        = sv_np[0],
        base_values   = base_val,
        data          = x_patient[0],
        feature_names = feature_names,
    )

    fig = plt.figure(figsize=(10, 5))
    shap.plots.waterfall(exp_obj, show=False)
    plt.title("Clinical risk factor contribution — this patient", fontsize=11)
    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format="png", dpi=130, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")