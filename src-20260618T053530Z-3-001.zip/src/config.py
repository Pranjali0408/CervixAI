import os

# ── AFTER (Colab version) ──────────────────────
# DRIVE_ROOT   = "/content/drive/MyDrive/cervical/"
# BASE_DIR     = "/content/drive/MyDrive/cervical/"
DRIVE_ROOT     ="/content/drive/MyDrive/cervical updated/"
BASE_DIR       ="/content/drive/MyDrive/cervical updated/"

IMAGE_DIR    = os.path.join(BASE_DIR, "data", "sipakmed")
CLINICAL_CSV = os.path.join(BASE_DIR, "data", "risk_factors_cervical_cancer.csv")
MODELS_DIR   = os.path.join(BASE_DIR, "models")
REPORTS_DIR  = os.path.join(BASE_DIR, "reports")

os.makedirs(MODELS_DIR,  exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)

IMG_SIZE    = 224
BATCH_SIZE  = 32
EPOCHS_HEAD = 30       # frozen backbone
EPOCHS_FINE = 20       # fine-tune top layers
LR_HEAD     = 1e-4
LR_FINE     = 1e-5
SEED        = 42

# ── Actual SIPaKMeD folder names (im_ prefix) ──────────────
SIPAK_CLASSES = [
    "im_Dyskeratotic",
    "im_Koilocytotic",
    "im_Metaplastic",
    "im_Parabasal",
    "im_Superficial-Intermediate",
]

# Architectures for comparative study (Point 4)
CNN_ARCHS = ["vgg16", "resnet50", "efficientnet_b0", "xception"]

# Map each SIPaKMeD class → clinical stage index
#   0 = Normal  |  1 = LSIL  |  2 = HSIL
SIPAK_TO_STAGE_IDX = {
    "im_Superficial-Intermediate": 0,   # Normal
    "im_Parabasal":                0,   # Normal
    "im_Metaplastic":              1,   # LSIL
    "im_Koilocytotic":             1,   # LSIL
    "im_Dyskeratotic":             2,   # HSIL
}

STAGE_NAMES        = ["Normal", "LSIL", "HSIL"]
NUM_STAGES         = 3          # final output classes

IMG_FEATURE_DIM    = 256        # CNN head output
CLINICAL_FEAT_DIM  = 32         # MLP encoder output

# Clinical CSV
DROP_COLS = [
    "STDs: Time since first diagnosis",
    "STDs: Time since last diagnosis",
]
CLINICAL_TARGET = "Biopsy"
