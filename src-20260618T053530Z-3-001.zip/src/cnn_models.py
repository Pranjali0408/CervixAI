"""
Model definitions:
  - build_cnn(arch)          : one of VGG16 / ResNet50 / EfficientNetB0 / Xception
                               for comparative study (image-only, 5-class SIPaKMeD)
  - build_mlp(n_features)    : clinical data encoder (MLP)
  - build_attention_fusion() : full multimodal model with attention-based fusion
"""

import tensorflow as tf
from tensorflow.keras import Model, Input
from tensorflow.keras.applications import (
    VGG16, ResNet50, EfficientNetB0, Xception,
)
from tensorflow.keras.layers import (
    Dense, Dropout, GlobalAveragePooling2D, BatchNormalization,
    Flatten, Concatenate, Multiply, Lambda, Reshape,
    MultiHeadAttention, LayerNormalization, GlobalAveragePooling1D,
    Activation, Add,
)
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2

from config import IMG_SHAPE, IMAGE_FEATURE_DIM, CLINICAL_FEATURE_DIM


# ─────────────────────────────────────────────────────────
#  Helper — shared dense head (used by all CNN branches)
# ─────────────────────────────────────────────────────────

def _dense_head(x, num_classes, feature_dim=IMAGE_FEATURE_DIM):
    x = BatchNormalization()(x)
    x = Dense(feature_dim, activation="relu",
               kernel_regularizer=l2(1e-4), name="img_feature_vec")(x)
    x = Dropout(0.4)(x)
    out = Dense(num_classes, activation="softmax", name="img_output")(x)
    return x, out          # return both feature vector AND logits


# ─────────────────────────────────────────────────────────
#  CNN comparative study  (image-only, all 4 architectures)
# ─────────────────────────────────────────────────────────

_BACKBONES = {
    "VGG16":         VGG16,
    "ResNet50":      ResNet50,
    "EfficientNetB0": EfficientNetB0,
    "Xception":      Xception,
}


def build_cnn(arch: str, num_classes: int, fine_tune_layers: int = 0):
    """
    Build a CNN for the image-only comparative study.

    Args:
        arch             : one of 'VGG16','ResNet50','EfficientNetB0','Xception'
        num_classes      : number of output classes
        fine_tune_layers : if > 0, unfreeze the last N backbone layers
                           (call this after initial frozen training)
    """
    if arch not in _BACKBONES:
        raise ValueError(f"Unknown arch '{arch}'. Choose from {list(_BACKBONES)}")

    base = _BACKBONES[arch](
        weights="imagenet", include_top=False, input_shape=IMG_SHAPE
    )
    base.trainable = False

    if fine_tune_layers > 0:
        for layer in base.layers[-fine_tune_layers:]:
            layer.trainable = True

    x = base.output
    x = GlobalAveragePooling2D()(x)
    feat, out = _dense_head(x, num_classes)

    model = Model(inputs=base.input, outputs=out, name=f"{arch}_classifier")
    model.compile(
        optimizer=Adam(1e-4),
        loss="categorical_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.AUC(name="auc"),
                 tf.keras.metrics.Recall(name="recall")],
    )
    return model


def get_feature_extractor(trained_cnn_model):
    """
    Slice a trained CNN at its feature vector layer for use in fusion.
    Returns a model: image → 256-dim feature vector.
    """
    return Model(
        inputs=trained_cnn_model.input,
        outputs=trained_cnn_model.get_layer("img_feature_vec").output,
        name="img_feature_extractor",
    )


# ─────────────────────────────────────────────────────────
#  MLP clinical encoder
# ─────────────────────────────────────────────────────────

def build_mlp(n_features: int):
    """
    Input layer → Dense(64) → Dense(32) → feature vector (32-dim).
    Compiled for binary clinical prediction (Biopsy label).
    """
    inp = Input(shape=(n_features,), name="clinical_input")
    x   = Dense(64, activation="relu", kernel_regularizer=l2(1e-4))(inp)
    x   = BatchNormalization()(x)
    x   = Dropout(0.3)(x)
    x   = Dense(CLINICAL_FEATURE_DIM, activation="relu",
                name="clinical_feature_vec")(x)
    x   = Dropout(0.2)(x)
    out = Dense(1, activation="sigmoid", name="clinical_output")(x)

    model = Model(inputs=inp, outputs=out, name="clinical_mlp")
    model.compile(
        optimizer=Adam(1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.AUC(name="auc"),
                 tf.keras.metrics.Recall(name="recall")],
    )
    return model


def get_clinical_extractor(trained_mlp):
    """Slice trained MLP at the 32-dim feature layer."""
    return Model(
        inputs=trained_mlp.input,
        outputs=trained_mlp.get_layer("clinical_feature_vec").output,
        name="clinical_feature_extractor",
    )


# ─────────────────────────────────────────────────────────
#  Attention-based multimodal fusion model
# ─────────────────────────────────────────────────────────

def _attention_gate(img_feat, clin_feat):
    """
    Learned attention weights over the two modalities.
    Returns a weighted combination of [img_feat, clin_feat].
    """
    total_dim = IMAGE_FEATURE_DIM + CLINICAL_FEATURE_DIM  # 256 + 32 = 288

    # Concatenate for context
    combined = Concatenate(name="raw_concat")([img_feat, clin_feat])

    # Attention scores per modality dim
    attn = Dense(total_dim, activation="tanh",  name="attn_tanh")(combined)
    attn = Dense(total_dim, activation="softmax", name="attn_weights")(attn)

    # Apply attention
    attended = Multiply(name="attended_features")([combined, attn])
    return attended


def build_attention_fusion(img_feat_dim=IMAGE_FEATURE_DIM,
                           clin_feat_dim=CLINICAL_FEATURE_DIM,
                           num_classes=3):
    """
    Takes pre-extracted feature vectors from both branches and fuses them
    with attention before the final classification head.

    Inputs : img_features  (batch, 256)
             clin_features (batch, 32)
    Output : softmax over num_classes (Normal / LSIL / HSIL)
    """
    img_in  = Input(shape=(img_feat_dim,),  name="image_features")
    clin_in = Input(shape=(clin_feat_dim,), name="clinical_features")

    attended = _attention_gate(img_in, clin_in)

    x = Dense(256, activation="relu", kernel_regularizer=l2(1e-4))(attended)
    x = BatchNormalization()(x)
    x = Dropout(0.4)(x)
    x = Dense(128, activation="relu", kernel_regularizer=l2(1e-4))(x)
    x = Dropout(0.3)(x)
    out = Dense(num_classes, activation="softmax", name="fusion_output")(x)

    model = Model(inputs=[img_in, clin_in], outputs=out,
                  name="attention_fusion")
    model.compile(
        optimizer=Adam(5e-4),
        loss="categorical_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.AUC(name="auc"),
                 tf.keras.metrics.Recall(name="recall")],
    )
    return model


# ─────────────────────────────────────────────────────────
#  End-to-end trainable fusion model (alternative)
# ─────────────────────────────────────────────────────────

def build_end_to_end_fusion(best_cnn_arch: str,
                            n_clinical_features: int,
                            num_classes: int = 3):
    """
    Single model with both branches trained jointly.
    Use this if you want to submit one .keras file.
    """
    base = _BACKBONES[best_cnn_arch](
        weights="imagenet", include_top=False, input_shape=IMG_SHAPE
    )
    base.trainable = False   # freeze during warmup; unfreeze for fine-tuning

    # Image branch
    img_in  = base.input
    x_img   = GlobalAveragePooling2D()(base.output)
    x_img   = BatchNormalization()(x_img)
    x_img   = Dense(IMAGE_FEATURE_DIM, activation="relu",
                    kernel_regularizer=l2(1e-4), name="img_feature_vec")(x_img)
    x_img   = Dropout(0.4)(x_img)

    # Clinical branch
    clin_in = Input(shape=(n_clinical_features,), name="clinical_input")
    x_clin  = Dense(64, activation="relu")(clin_in)
    x_clin  = BatchNormalization()(x_clin)
    x_clin  = Dropout(0.3)(x_clin)
    x_clin  = Dense(CLINICAL_FEATURE_DIM, activation="relu",
                    name="clinical_feature_vec")(x_clin)

    # Attention fusion
    attended = _attention_gate(x_img, x_clin)
    x = Dense(256, activation="relu", kernel_regularizer=l2(1e-4))(attended)
    x = BatchNormalization()(x)
    x = Dropout(0.4)(x)
    x = Dense(128, activation="relu")(x)
    x = Dropout(0.3)(x)
    out = Dense(num_classes, activation="softmax",
                name="fusion_output")(x)

    model = Model(inputs=[img_in, clin_in], outputs=out,
                  name="e2e_attention_fusion")
    model.compile(
        optimizer=Adam(1e-4),
        loss="categorical_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.AUC(name="auc"),
                 tf.keras.metrics.Recall(name="recall")],
    )
    return model
