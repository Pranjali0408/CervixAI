
"""
PyTorch model definitions:

  CNNClassifier(arch, num_classes)   — VGG16 | ResNet50 | EfficientNetB0 | Xception
  ClinicalMLP(n_features)            — Input→64→32→feature vector
  AttentionFusion(img_dim, clin_dim) — attention-weighted multimodal fusion

Xception is loaded from the `timm` library (pip install timm).
All other backbones use torchvision.
"""

import torch
import torch.nn as nn
import torchvision.models as tvm

from config import IMG_FEATURE_DIM, CLINICAL_FEAT_DIM, NUM_STAGES


# ──────────────────────────────────────────────────────────
#  CNN backbone wrapper — 4 architectures (Point 4)
# ──────────────────────────────────────────────────────────

class CNNClassifier(nn.Module):
    """
    Pretrained ImageNet backbone → custom head:
      backbone → GlobalAvgPool → BN → Linear(256) → ReLU → Dropout → Linear(n_classes)

    The 256-dim intermediate layer is exposed via forward_features() for fusion.

    Supported arch values:
      'vgg16'           — baseline (torchvision)
      'resnet50'        — deep residual (torchvision)
      'efficientnet_b0' — efficient CNN (torchvision)
      'xception'        — advanced CNN (timm)
    """

    def __init__(self, arch: str = "resnet50",
                 num_classes: int = NUM_STAGES,
                 freeze_backbone: bool = True):
        super().__init__()
        arch = arch.lower()
        self.arch = arch

        backbone, in_feat = self._build_backbone(arch)
        self.backbone = backbone

        if freeze_backbone:
            for p in self.backbone.parameters():
                p.requires_grad = False

        self.head = nn.Sequential(
            nn.BatchNorm1d(in_feat),
            nn.Linear(in_feat, IMG_FEATURE_DIM),
            nn.ReLU(inplace=False),
            nn.Dropout(0.4),
        )
        self.classifier = nn.Linear(IMG_FEATURE_DIM, num_classes)

    @staticmethod
    def _build_backbone(arch):
        """
        Returns (backbone_module, out_feature_dim).
        All backbones are stripped of their original classifier so
        forward() returns a flat feature vector.
        """
        if arch == "vgg16":
            m        = tvm.vgg16(weights=tvm.VGG16_Weights.DEFAULT)
            in_feat  = m.classifier[0].in_features   # 25088
            m.classifier = nn.Identity()
            return m, in_feat

        elif arch == "resnet50":
            m       = tvm.resnet50(weights=tvm.ResNet50_Weights.DEFAULT)
            in_feat = m.fc.in_features               # 2048
            m.fc    = nn.Identity()
            return m, in_feat

        elif arch == "efficientnet_b0":
            m        = tvm.efficientnet_b0(weights=tvm.EfficientNet_B0_Weights.DEFAULT)
            in_feat  = m.classifier[1].in_features   # 1280
            m.classifier = nn.Identity()
            return m, in_feat

        elif arch == "xception":
            try:
                import timm
            except ImportError:
                raise ImportError(
                    "timm is required for Xception. "
                    "Install with: pip install timm"
                )
            # num_classes=0 → backbone returns feature vector directly
            m       = timm.create_model("xception", pretrained=True,
                                         num_classes=0)
            in_feat = m.num_features          # 2048
            return m, in_feat

        else:
            raise ValueError(
                f"Unknown arch '{arch}'. "
                f"Choose from: vgg16, resnet50, efficientnet_b0, xception"
            )

    def unfreeze_top(self, n_layers: int = 30):
        """Unfreeze the last n_layers of backbone parameters for fine-tuning."""
        params = list(self.backbone.parameters())
        for p in params[-n_layers:]:
            p.requires_grad = True
        trainable = sum(p.requires_grad for p in self.backbone.parameters())
        print(f"  Unfrozen last {n_layers} backbone params "
              f"({trainable} total trainable backbone params).")

    def forward_features(self, x):
        """Return 256-dim feature vector. Used for fusion & Grad-CAM."""
        x = self.backbone(x)
        return self.head(x)

    def forward(self, x):
        return self.classifier(self.forward_features(x))

    # ── Grad-CAM target layer registry ─────────────────────
    def get_gradcam_layer(self):
        """
        Return the last convolutional layer appropriate for Grad-CAM,
        selected per architecture.
        """
        a = self.arch
        if a == "vgg16":
            # features[-3] is the last Conv2d before final MaxPool
            return self.backbone.features[-3]
        elif a == "resnet50":
            # last bottleneck conv3 in layer4
            return self.backbone.layer4[-1].conv3
        elif a == "efficientnet_b0":
            # last conv in features block
            return self.backbone.features[-1][0]
        elif a == "xception":
            # last conv in timm Xception
            try:
                return self.backbone.act4   # activation after last conv
            except AttributeError:
                # fallback: last Conv2d
                last = None
                for m in self.backbone.modules():
                    if isinstance(m, nn.Conv2d):
                        last = m
                return last
        return None


# ──────────────────────────────────────────────────────────
#  Clinical MLP encoder  (Point 6)
# ──────────────────────────────────────────────────────────

class ClinicalMLP(nn.Module):
    """
    Input(n_features) → Dense(64, ReLU) → Dense(32, ReLU) → feature_vec(32)
    Output head: single sigmoid neuron for binary Biopsy prediction.
    """
    def __init__(self, n_features: int):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(n_features, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(inplace=False),
            nn.Dropout(0.3),
            nn.Linear(64, CLINICAL_FEAT_DIM),   # 32-dim output
            nn.ReLU(inplace=False),
            nn.Dropout(0.2),
        )
        self.classifier = nn.Linear(CLINICAL_FEAT_DIM, 1)

    def forward_features(self, x):
        """Return 32-dim feature vector."""
        return self.encoder(x)

    def forward(self, x):
        return self.classifier(self.forward_features(x)).squeeze(1)


# ──────────────────────────────────────────────────────────
#  Attention-based fusion head  (Point 7)
# ──────────────────────────────────────────────────────────

class AttentionGate(nn.Module):
    """
    Soft attention over the concatenated (img + clinical) feature vector.
    Learns which dimensions matter for each prediction.
    """
    def __init__(self, total_dim: int):
        super().__init__()
        self.attn = nn.Sequential(
            nn.Linear(total_dim, total_dim),
            nn.Tanh(),
            nn.Linear(total_dim, total_dim),
            nn.Softmax(dim=-1),
        )

    def forward(self, x):
        return x * self.attn(x)


class AttentionFusion(nn.Module):
    """
    img_feat (B, 256) + clin_feat (B, 32)
      → Concatenate (B, 288)
      → AttentionGate
      → Dense(256) → Dense(128) → Dense(num_classes)
    """
    def __init__(self,
                 img_dim: int    = IMG_FEATURE_DIM,
                 clin_dim: int   = CLINICAL_FEAT_DIM,
                 num_classes: int = NUM_STAGES):
        super().__init__()
        total      = img_dim + clin_dim   # 256 + 32 = 288
        self.gate  = AttentionGate(total)
        self.head  = nn.Sequential(
            nn.Linear(total, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=False),
            nn.Dropout(0.4),
            nn.Linear(256, 128),
            nn.ReLU(inplace=False),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes),
        )

    def forward(self, img_feat, clin_feat):
        combined = torch.cat([img_feat, clin_feat], dim=1)
        attended = self.gate(combined)
        return self.head(attended)